const getKlines = require("./modules/collectors/getKlines");
const calculateRSI = require("./modules/indicators/rsiAnalyzer").calculateRSI;
const calculateEMA = require("./modules/indicators/ema").calculateEMA;

const SYMBOL = "BTC-USDT"; // ✔️ Добавлен дефис, как требует BingX
const INTERVAL = "15m";
const LIMIT = 100;

(async () => {
  console.log(`🧪 Тест: ${SYMBOL} | Таймфрейм: ${INTERVAL}`);

  const candles = await getKlines(SYMBOL, INTERVAL, LIMIT);

  if (!candles || candles.length < 50) {
    console.error("❌ Недостаточно данных для расчёта.");
    return;
  }

  const closes = candles.map(c => c.close);
  console.log("🔢 Последние 5 закрытий:", closes.slice(-5).map(p => p.toFixed(2)));

  const rsi = calculateRSI(closes, 14);
  const ema9 = calculateEMA(closes, 9);
  const ema20 = calculateEMA(closes, 20);
  const ema50 = calculateEMA(closes, 50);

  console.log("📈 RSI(14):", rsi[rsi.length - 1].toFixed(2));
  console.log("📉 EMA(9):", ema9[ema9.length - 1].toFixed(2));
  console.log("📉 EMA(20):", ema20[ema20.length - 1].toFixed(2));
  console.log("📉 EMA(50):", ema50[ema50.length - 1].toFixed(2));
})();