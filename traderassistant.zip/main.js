const TelegramBot = require("node-telegram-bot-api");
const getMultiSnapshot = require("./modules/collectors/getMultiSnapshot");
const handlePositionRequest = require("./modules/trade/positionHandler").handlePositionRequest;
const checkPnLDrop = require("./modules/alerts/checkPnLDrop"); // новый модуль

const TOKEN = process.env.BOT_TOKEN;
const bot = new TelegramBot(TOKEN, { polling: true });

// Активируем обработчик позиций
handlePositionRequest(bot);

const SYMBOLS = [
  "PIXEL-USDT",
  "PORTAL-USDT",
  "HYPE-USDT",
  "1000BONK-USDT",
  "ARB-USDT",
  "BTC-USDT",
  "SOL-USDT"
];

const INTERVALS = ["1m", "3m", "5m", "15m", "30m", "1h"];

const mainMenu = {
  reply_markup: {
    keyboard: [
      ["📊 Обзор рынка", "🎯 Мои позиции"],
      ["🔍 Анализ монет"]
    ],
    resize_keyboard: true,
    one_time_keyboard: false
  }
};

const coinsMenu = {
  reply_markup: {
    keyboard: [
      ["📈 BTC-USDT", "📈 ARB-USDT"],
      ["📈 HYPE-USDT", "📈 1000BONK-USDT"],
      ["📈 PIXEL-USDT", "📈 PORTAL-USDT"],
      ["📈 SOL-USDT"],
      ["⬅️ Назад"]
    ],
    resize_keyboard: true,
    one_time_keyboard: false
  }
};

const sleep = (ms) => new Promise((res) => setTimeout(res, ms));

bot.onText(/\/start/, (msg) => {
  bot.sendMessage(msg.chat.id, "👋 Привет! Выбери, что анализировать:", mainMenu);
});

bot.on("message", async (msg) => {
  const chatId = msg.chat.id;
  const text = msg.text;

  if (text === "📊 Обзор рынка") {
    bot.sendMessage(chatId, "⏳ Собираю данные по всем парам...");
    let response = `📊 Обзор всех пар (все таймфреймы)\n\n`;

    for (const symbol of SYMBOLS) {
      try {
        const data = await getMultiSnapshot(symbol);
        response += `🔹 *${symbol}*\n`;

        for (const interval of INTERVALS) {
          const s = data.snapshots[interval];
          if (!s) continue;
          response += `🕒 ${interval} | Цена: ${s.currentPrice} | RSI: ${s.rsi} | EMA9: ${s.ema9} | EMA20: ${s.ema20} | EMA50: ${s.ema50} | Объём: ${s.volume}\n`;
          await sleep(250);
        }

        response += "\n";
      } catch (err) {
        response += `❌ ${symbol}: ошибка получения данных\n\n`;
      }

      await sleep(500);
    }

    const MAX_LENGTH = 4000;
    for (let i = 0; i < response.length; i += MAX_LENGTH) {
      const chunk = response.slice(i, i + MAX_LENGTH);
      await bot.sendMessage(chatId, chunk, { parse_mode: "Markdown" });
    }
  }

  else if (text === "🔍 Анализ монет") {
    bot.sendMessage(chatId, "📈 Выбери монету для анализа:", coinsMenu);
  }

  else if (text === "⬅️ Назад") {
    bot.sendMessage(chatId, "🔙 Возврат в главное меню:", mainMenu);
  }

  else if (text.startsWith("📈")) {
    const symbol = text.replace("📈 ", "");
    bot.sendMessage(chatId, `⏳ Анализ по паре ${symbol}...`);

    try {
      const data = await getMultiSnapshot(symbol);
      let response = `📊 ${symbol} — анализ по таймфреймам\n\n`;

      for (const interval of INTERVALS) {
        const s = data.snapshots[interval];
        if (!s) continue;
        response += `🕒 ${interval} | Цена: ${s.currentPrice} | RSI: ${s.rsi} | EMA9: ${s.ema9} | EMA20: ${s.ema20} | EMA50: ${s.ema50} | Объём: ${s.volume}\n`;
        await sleep(250);
      }

      bot.sendMessage(chatId, response);
    } catch (err) {
      bot.sendMessage(chatId, `❌ Ошибка получения данных по паре ${symbol}`);
    }
  }
});

// 🔁 Проверка убытков по позициям каждые 3 минуты
setInterval(() => {
  checkPnLDrop(bot);
}, 60 * 1000); // 1 минуты