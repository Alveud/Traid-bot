const { addPosition, getTrackedPositions } = require("./modules/trade/positionTracker");

// Пример: добавим пару сделок
addPosition("BTC-USDT", 117500);
addPosition("ARB-USDT", 0.4034);

// Получим текущие отслеживаемые позиции
const positions = getTrackedPositions();

console.log("📌 Отслеживаемые позиции:");
positions.forEach((pos) => {
  console.log(`\\n🔹 Пара: ${pos.symbol}`);
  console.log(`   Вход: ${pos.entryPrice}`);
  console.log(`   Take Profit: ${pos.takeProfit}`);
  console.log(`   Stop Loss: ${pos.stopLoss}`);
});

