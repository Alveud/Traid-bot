const OpenAI = require("openai");

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

async function analyzeWithGPT(symbol, snapshot) {
  const prompt = `
Ты опытный трейдер. Проанализируй криптопару ${symbol} на основе следующих данных по таймфреймам (5m, 15m, 30m, 1h):

${JSON.stringify(snapshot, null, 2)}

Дай краткий и чёткий вердикт:
- Входить в LONG / SHORT / ЖДАТЬ
- Почему
- Вывод одной строкой для трейдера.

Отвечай кратко, как трейдер. Без воды.
`;

  const chatCompletion = await openai.chat.completions.create({
    model: "gpt-3.5-turbo",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.4,
  });

  return chatCompletion.choices[0].message.content;
}

module.exports = analyzeWithGPT;