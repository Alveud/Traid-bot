function formatPositions(positions) {
  if (!positions || positions.length === 0) {
    return "📉 У тебя сейчас нет открытых позиций.";
  }

  let message = `🎯 *Мои открытые позиции:*\n\n`;

  positions.forEach((pos) => {
    const symbol = pos.symbol || "???";
    const side = pos.side || "???";
    const entry = pos.entryPrice || "-";
    const pnl = pos.pnlPercentage !== undefined ? `${pos.pnlPercentage.toFixed(1)}%` : "N/A";

    message += `📌 *${symbol}* — ${side.toUpperCase()}\n🎯 Entry: ${entry}\n💰 PnL: ${pnl}\n\n`;
  });

  return message;
}

module.exports = { formatPositions };