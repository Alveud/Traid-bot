const { getOpenPositions } = require("../trade/getPositions");

function formatPositions(positions) {
  if (!positions || positions.length === 0) {
    return "📉 У тебя сейчас нет открытых позиций.";
  }

  let message = "🎯 *Мои открытые позиции:*\n";

  positions.forEach(pos => {
    const symbol = pos.symbol || "???";
    const side = pos.side?.toUpperCase() || "???";
    const entry = pos.entryPrice !== undefined ? pos.entryPrice.toFixed(4) : "-";
    const pnl = pos.pnlPercentage !== undefined ? `${pos.pnlPercentage.toFixed(2)}%` : "N/A";

    message += `\n📌 *${symbol}* — *${side}*\n🎯 Вход: ${entry}\n💰 PnL: ${pnl}\n`;
  });

  return message;
}

function handlePositionRequest(bot) {
  if (!bot || typeof bot.on !== "function") {
    console.error("❌ Бот не передан или не поддерживает метод 'on'");
    return;
  }

  bot.on("message", async (msg) => {
    if (!msg || !msg.text) return;

    if (msg.text === "🎯 Мои позиции") {
      const chatId = msg.chat.id;

      try {
        const positions = await getOpenPositions();
        const message = formatPositions(positions);
        await bot.sendMessage(chatId, message, { parse_mode: "Markdown" });
      } catch (err) {
        console.error("❌ Ошибка получения позиций:", err.message);
        await bot.sendMessage(chatId, "🚫 Не удалось получить позиции. Проверь API ключи или интернет.");
      }
    }
  });
}

module.exports = { handlePositionRequest };