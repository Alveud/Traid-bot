const axios = require("axios");
const crypto = require("crypto");

const API_KEY = process.env.BINGX_API_KEY;
const SECRET_KEY = process.env.BINGX_SECRET_KEY;
const BASE_URL = "https://open-api.bingx.com";
const RECV_WINDOW = 5000;

function getSignature(queryString, secretKey) {
  return crypto.createHmac("sha256", secretKey).update(queryString).digest("hex");
}

async function getOpenPositions() {
  const timestamp = Date.now();
  const query = `timestamp=${timestamp}&recvWindow=${RECV_WINDOW}`;
  const signature = getSignature(query, SECRET_KEY);

  const url = `${BASE_URL}/openApi/swap/v2/user/positions?${query}&signature=${signature}`;

  try {
    const response = await axios.get(url, {
      headers: {
        "X-BX-APIKEY": API_KEY,
      },
    });

    const data = response.data;
    console.log("👉 Ответ от BingX:", JSON.stringify(data, null, 2));

    if (data?.code === 0 && Array.isArray(data.data)) {
      return data.data
        .filter(p => parseFloat(p.positionAmt) !== 0)
        .map(p => ({
          symbol: p.symbol,
          side: p.positionSide,
          entryPrice: parseFloat(p.avgPrice),
          pnlPercentage: parseFloat(p.pnlRatio) * 100
        }));
    } else {
      console.error("BingX API error:", data?.msg || "Unknown error");
      return [];
    }

  } catch (err) {
    console.error("❌ Ошибка получения позиций:", err.message);
    return [];
  }
}

module.exports = { getOpenPositions };