const getKlines = require("./getKlines");
const { calculateRSI } = require("../indicators/rsiAnalyzer");
const { calculateEMA } = require("../indicators/ema");

async function getSnapshotForInterval(symbol, interval) {
  const candles = await getKlines(symbol, interval, 50);

  const closePrices = candles.map(c => parseFloat(c.close));
  const lastCandle = candles[candles.length - 1];
  const rawRsi = calculateRSI(closePrices, 14);
  const rsi = Array.isArray(rawRsi) ? rawRsi[rawRsi.length - 1] : rawRsi;
  const ema9 = calculateEMA(closePrices, 9);
  const ema20 = calculateEMA(closePrices, 20);
  const ema50 = calculateEMA(closePrices, 50);

  return {
    currentPrice: parseFloat(lastCandle.close),
    rsi: parseFloat(rsi).toFixed(2),
    ema9: parseFloat(ema9).toFixed(2),
    ema20: parseFloat(ema20).toFixed(2),
    ema50: parseFloat(ema50).toFixed(2),
    volume: parseFloat(lastCandle.volume)
  };
}

async function getMultiSnapshot(symbol, intervals = ["1m", "3m", "5m", "15m", "30m", "1h"]) {
  const result = {
    symbol,
    snapshots: {}
  };

  for (const interval of intervals) {
    try {
      result.snapshots[interval] = await getSnapshotForInterval(symbol, interval);
    } catch (err) {
      result.snapshots[interval] = { error: err.message };
    }
  }

  return result;
}

module.exports = getMultiSnapshot;
