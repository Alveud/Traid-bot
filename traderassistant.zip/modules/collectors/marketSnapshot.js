const getKlines = require("./getKlines");
const getPrice = require("./getPrice"); // добавляем импорт
const { calculateRSI } = require("../indicators/rsiAnalyzer");
const { calculateEMA } = require("../indicators/ema");

async function getMarketSnapshot(symbol, interval) {
  const candles = await getKlines(symbol, interval, 50); // последние 50 свечей

  if (!candles || candles.length < 20) {
    throw new Error("Недостаточно данных для анализа");
  }

  const closePrices = candles.map(c => parseFloat(c.close));
  const lastCandle = candles[candles.length - 1];

  const rawRsi = calculateRSI(closePrices, 14);
  const rsi = Array.isArray(rawRsi) ? rawRsi[rawRsi.length - 1] : rawRsi;

  const ema9 = calculateEMA(closePrices, 9);
  const ema20 = calculateEMA(closePrices, 20);
  const ema50 = calculateEMA(closePrices, 50);

  let realPrice = null;
  try {
    realPrice = await getPrice(symbol); // получаем реальную цену
  } catch (e) {
    console.error("❌ Ошибка получения текущей цены:", e.message);
  }

  const snapshot = {
    symbol,
    interval,
    closePrices: closePrices.slice(-5),
    currentPrice: parseFloat(realPrice) || parseFloat(lastCandle.close), // если реальная цена есть — используем её
    rsi: parseFloat(rsi).toFixed(2),
    ema9: parseFloat(ema9).toFixed(2),
    ema20: parseFloat(ema20).toFixed(2),
    ema50: parseFloat(ema50).toFixed(2),
    volume: parseFloat(lastCandle.volume),
    candle: {
      open: parseFloat(lastCandle.open),
      high: parseFloat(lastCandle.high),
      low: parseFloat(lastCandle.low),
      close: parseFloat(lastCandle.close)
    }
  };

  return snapshot;
}

module.exports = getMarketSnapshot;