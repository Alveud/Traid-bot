const axios = require("axios");
const crypto = require("crypto");

const apiKey = process.env.BINGX_API_KEY;
const secretKey = process.env.BINGX_SECRET_KEY;
const BASE_URL = "https://open-api.bingx.com";

function getTimestamp() {
  return Date.now().toString();
}

function createSignature(params) {
  const sorted = Object.keys(params).sort();
  const query = sorted.map(k => `${k}=${params[k]}`).join("&");
  return crypto.createHmac("sha256", secretKey).update(query).digest("hex");
}

async function getKlines(symbol = "BTC-USDT", interval = "1m", limit = 10) {
  const timestamp = getTimestamp();
  const params = {
    symbol,
    interval,
    limit,
    recvWindow: "5000",
    timestamp
  };
  const signature = createSignature(params);
  const fullParams = { ...params, signature };

  const query = Object.keys(fullParams)
    .map(k => `${k}=${encodeURIComponent(fullParams[k])}`)
    .join("&");

  try {
    const res = await axios.get(`${BASE_URL}/openApi/swap/v3/quote/klines?${query}`, {
      headers: { "X-BX-APIKEY": apiKey }
    });

    const candles = res.data?.data;

    if (!candles || !Array.isArray(candles)) {
      console.error("❌ Неверный формат данных:", res.data);
      return [];
    }

    return candles.map(item => {
      const isArray = Array.isArray(item);
      const getSafe = (val) => (val !== undefined && val !== null && val !== "null" ? val : null);

      return {
        openTime: Number(getSafe(isArray ? item[0] : item.openTime || item.startTime)),
        open: parseFloat(getSafe(isArray ? item[1] : item.open)),
        high: parseFloat(getSafe(isArray ? item[2] : item.high)),
        low: parseFloat(getSafe(isArray ? item[3] : item.low)),
        close: parseFloat(getSafe(isArray ? item[4] : item.close)),
        volume: parseFloat(getSafe(isArray ? item[5] : item.volume)),
        closeTime: Number(getSafe(isArray ? item[6] : item.closeTime || item.endTime))
      };
    });
  } catch (err) {
    console.error("❌ Ошибка getKlines:", err.response?.data || err.message);
    return null;
  }
}

module.exports = getKlines;