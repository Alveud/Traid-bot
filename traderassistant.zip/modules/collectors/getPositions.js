const axios = require("axios");
const crypto = require("crypto");

const API_KEY = process.env.BINGX_API_KEY;
const SECRET_KEY = process.env.BINGX_SECRET_KEY;

async function getOpenPositions() {
  const timestamp = Date.now();
  const recvWindow = 5000;

  const query = `timestamp=${timestamp}&recvWindow=${recvWindow}`;
  const signature = crypto
    .createHmac("sha256", SECRET_KEY)
    .update(query)
    .digest("hex");

  const url = `https://open-api.bingx.com/openApi/swap/v2/user/positions?${query}&signature=${signature}`;

  try {
    const response = await axios.get(url, {
      headers: {
        "X-BX-APIKEY": API_KEY
      }
    });

    const data = response.data.data || [];
    return data
      .filter(pos => Number(pos.positionSize) !== 0)
      .map(pos => ({
        symbol: pos.symbol.replace("USDT", "/USDT"),
        side: pos.positionSide === "LONG" ? "LONG" : "SHORT",
        entryPrice: parseFloat(pos.entryPrice),
        pnlPercentage: parseFloat(pos.unrealizedProfitRate)
      }));
  } catch (err) {
    console.error("Ошибка при получении позиций с BingX:", err.response?.data || err.message);
    return [];
  }
}

module.exports = { getOpenPositions };