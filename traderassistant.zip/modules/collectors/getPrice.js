// getPrice.js
const axios = require("axios");
const crypto = require("crypto");

const apiKey = process.env.BINGX_API_KEY;
const secretKey = process.env.BINGX_SECRET_KEY;
const BASE_URL = "https://open-api.bingx.com";

function getTimestamp() {
  return Date.now().toString();
}

function createSignature(params) {
  const sorted = Object.keys(params).sort();
  const query = sorted.map(k => `${k}=${params[k]}`).join("&");
  return crypto.createHmac("sha256", secretKey).update(query).digest("hex");
}

async function getPrice(symbol = "BTC-USDT") {
  const timestamp = getTimestamp();
  const params = {
    symbol,
    recvWindow: "5000",
    timestamp
  };
  const signature = createSignature(params);
  const fullParams = { ...params, signature };

  const query = Object.keys(fullParams)
    .map(k => `${k}=${encodeURIComponent(fullParams[k])}`)
    .join("&");

  try {
    const res = await axios.get(`${BASE_URL}/openApi/swap/v2/quote/price?${query}`, {
      headers: { "X-BX-APIKEY": apiKey }
    });
    return res.data?.data?.price || null;
  } catch (err) {
    console.error("❌ Ошибка getPrice:", err.response?.data || err.message);
    return null;
  }
}

module.exports = getPrice;