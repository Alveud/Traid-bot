const getMarketSnapshot = require('../collectors/marketSnapshot');

const SYMBOLS = [
  'PIXEL-USDT',
  'PORTAL-USDT',
  'HYPE-USDT',
  '1000BONK-USDT',
  'ARB-USDT',
  'BTC-USDT',
  'SOL-USDT'
];

const INTERVAL = '15m';

(async () => {
  for (const symbol of SYMBOLS) {
    try {
      const snapshot = await getMarketSnapshot(symbol, INTERVAL);
      console.log('===============================');
      console.log(`📈 ${symbol} | Таймфрейм: ${INTERVAL}`);
      console.log(`Цена: ${snapshot.currentPrice}`);
      console.log(`RSI(14): ${snapshot.rsi}`);
      console.log(`EMA(9): ${snapshot.ema9}`);
      console.log(`EMA(20): ${snapshot.ema20}`);
      console.log(`EMA(50): ${snapshot.ema50}`);
      console.log(`Объём: ${snapshot.volume}`);
      console.log(`Закрытия: ${snapshot.closePrices.join(', ')}`);
    } catch (err) {
      console.error(`❌ Ошибка по паре ${symbol}:`, err.message);
    }
  }
})();
