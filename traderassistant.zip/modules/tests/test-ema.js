const getKlines = require("./getKlines");
const calculateEMA = require("./ema");

(async () => {
  const candles = await getKlines("BTC-USDT", "5m", 30);
  const closes = candles.map(c => c.close).filter(Boolean);

  const ema = calculateEMA(closes, 9);
  console.log("📈 EMA (9):");
  console.log(ema);
})();