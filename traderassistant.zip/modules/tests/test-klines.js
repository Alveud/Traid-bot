const getKlines = require("./getKlines");

(async () => {
  const klines = await getKlines("BTC-USDT", "5m", 10);
  console.table(klines);
})();