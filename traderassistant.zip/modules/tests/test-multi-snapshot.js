const getMultiSnapshot = require('../collectors/getMultiSnapshot');

(async () => {
  const data = await getMultiSnapshot("BTC-USDT");
  console.log(JSON.stringify(data, null, 2));
})();
