const getKlines = require('./getKlines');
const { calculateRSI } = require('./rsiAnalyzer');

const symbol = 'BTC-USDT';
const interval = '15m';
const limit = 100; // минимум 15 + период RSI (14), так что 100 — ок

(async () => {
  try {
    const candles = await getKlines(symbol, interval, limit);
    const closes = candles.map(c => c.close);

    const period = 14;
    const rsiValues = calculateRSI(closes, period);

    if (!rsiValues || rsiValues.length === 0) {
      console.log('❌ Не удалось рассчитать RSI.');
      return;
    }

    const latestRSI = rsiValues[rsiValues.length - 1];
    console.log(`📊 RSI (${period}): ${latestRSI}`);

    // Простейший сигнал
    if (latestRSI < 30) {
      console.log('🟢 Сигнал на вход в LONG (перепроданность)');
    } else if (latestRSI > 70) {
      console.log('🔴 Сигнал на вход в SHORT (перекупленность)');
    } else {
      console.log('⚪ Нет сигнала, наблюдаем...');
    }

  } catch (err) {
    console.error('Ошибка при тесте RSI:', err.message);
  }
})();