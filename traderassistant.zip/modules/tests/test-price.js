const getPrice = require("./getPrice");

(async () => {
  const price = await getPrice("BTC-USDT");
  console.log("💰 Цена BTC/USDT:", price);
})();