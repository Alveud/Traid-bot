const getMarketSnapshot = require('../collectors/marketSnapshot');

(async () => {
  const data = await getMarketSnapshot('BTC-USDT', '15m');
  console.log(data);
})();