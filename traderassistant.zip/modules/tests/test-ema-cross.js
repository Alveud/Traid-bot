const getKlines = require("./getKlines");
const { calculateEMA } = require("./ema");

(async () => {
  const symbol = "BTC-USDT";
  const interval = "5m";
  const limit = 100;

  const candles = await getKlines(symbol, interval, limit);

  if (!candles) {
    console.error("❌ Нет данных по свечам");
    return;
  }

  const closes = candles.map(c => c.close);

  const shortEMA = calculateEMA(closes, 9);  // Быстрая EMA
  const longEMA = calculateEMA(closes, 21);  // Медленная EMA

  console.log("📉 EMA (9):", shortEMA.slice(-5));
  console.log("📈 EMA (21):", longEMA.slice(-5));

  const len = Math.min(shortEMA.length, longEMA.length);

  if (len < 2) {
    console.log("Недостаточно данных для анализа кросса EMA");
    return;
  }

  const prevShort = shortEMA[len - 2];
  const prevLong = longEMA[len - 2];
  const currShort = shortEMA[len - 1];
  const currLong = longEMA[len - 1];

  if (prevShort < prevLong && currShort > currLong) {
    console.log("🟢 EMA Кросс вверх! Сигнал на ПОКУПКУ!");
  } else if (prevShort > prevLong && currShort < currLong) {
    console.log("🔴 EMA Кросс вниз! Сигнал на ПРОДАЖУ!");
  } else {
    console.log("⚪ Нет сигнала на вход. Ждём...");
  }
})();