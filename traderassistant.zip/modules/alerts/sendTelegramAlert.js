const axios = require("axios");
const { config } = require("dotenv");
config();

const TELEGRAM_TOKEN = process.env.BOT_TOKEN;
const TELEGRAM_CHAT_ID = process.env.CHAT_ID;

async function sendTelegramAlert(message) {
  if (!TELEGRAM_TOKEN || !TELEGRAM_CHAT_ID) {
    console.error("❌ Отсутствует BOT_TOKEN или CHAT_ID");
    return;
  }

  const url = `https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`;

  try {
    await axios.post(url, {
      chat_id: TELEGRAM_CHAT_ID,
      text: message,
      parse_mode: "Markdown"
    });
    console.log("📬 Уведомление отправлено в Telegram");
  } catch (error) {
    console.error("❌ Ошибка при отправке в Telegram:", error.response?.data || error.message);
  }
}

module.exports = sendTelegramAlert;