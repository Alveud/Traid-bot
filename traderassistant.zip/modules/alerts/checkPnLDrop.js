const { getOpenPositions } = require("../trade/getPositions");

let lastAlerts = {}; // Отслеживаем последнее уведомление по каждой паре

async function checkPnLDrop(bot, chatId) {
  try {
    const positions = await getOpenPositions();

    if (!positions || positions.length === 0) return;

    const now = Date.now();

    for (const pos of positions) {
      const symbol = pos.symbol;
      const pnl = pos.pnlPercentage;

      if (pnl !== undefined && pnl <= -10) {
        const lastAlertTime = lastAlerts[symbol] || 0;
        const minutesPassed = (now - lastAlertTime) / (1000 * 60);

        if (minutesPassed >= 5) {
          await bot.sendMessage(chatId,
            `⚠️ *Просадка по ${symbol}*: ${pnl.toFixed(2)}%\n` +
            `Что делаем? 💭 Хедж или усреднение?`,
            { parse_mode: "Markdown" }
          );
          lastAlerts[symbol] = now;
        }
      }
    }
  } catch (err) {
    console.error("❌ Ошибка при проверке PnL:", err.message);
  }
}

module.exports = { checkPnLDrop };
