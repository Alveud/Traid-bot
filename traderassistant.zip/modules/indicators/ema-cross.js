function detectEMACross(emaShort, emaLong) {
  if (!Array.isArray(emaShort) || !Array.isArray(emaLong)) {
    throw new Error("EMA inputs must be arrays");
  }

  const signals = [];

  const len = Math.min(emaShort.length, emaLong.length);

  for (let i = 1; i < len; i++) {
    const prevShort = emaShort[i - 1];
    const prevLong = emaLong[i - 1];
    const currShort = emaShort[i];
    const currLong = emaLong[i];

    if (prevShort < prevLong && currShort > currLong) {
      signals.push({ index: i, signal: "LONG" });
    } else if (prevShort > prevLong && currShort < currLong) {
      signals.push({ index: i, signal: "SHORT" });
    }
  }

  return signals;
}

module.exports = { detectEMACross };