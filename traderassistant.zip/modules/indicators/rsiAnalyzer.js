// rsiAnalyzer.js

function calculateRSI(closes, period = 14) {
  if (!Array.isArray(closes) || closes.length < period + 1) {
    console.error("❌ Недостаточно данных для расчета RSI");
    return null;
  }

  const rsi = [];
  let gains = 0;
  let losses = 0;

  // Считаем начальные средние
  for (let i = 1; i <= period; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff >= 0) {
      gains += diff;
    } else {
      losses -= diff;
    }
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;

  rsi[period] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);

  // Основной цикл расчета RSI
  for (let i = period + 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff >= 0) {
      avgGain = (avgGain * (period - 1) + diff) / period;
      avgLoss = (avgLoss * (period - 1)) / period;
    } else {
      avgGain = (avgGain * (period - 1)) / period;
      avgLoss = (avgLoss * (period - 1) - diff) / period;
    }

    const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
    const currentRSI = avgLoss === 0 ? 100 : 100 - 100 / (1 + rs);
    rsi[i] = parseFloat(currentRSI.toFixed(2));
  }

  // Возвращаем только рассчитанные значения RSI
  return rsi.slice(period);
}

module.exports = { calculateRSI };