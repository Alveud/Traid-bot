// 📉 Функция для расчёта экспоненциальной скользящей средней (EMA)
function calculateEMA(data, period = 9) {
  if (!Array.isArray(data) || data.length < period) {
    console.error("⛔ Недостаточно данных для расчета EMA");
    return [];
  }

  const ema = [];
  const multiplier = 2 / (period + 1);

  // Первая точка EMA — это SMA (простая скользящая средняя)
  const firstSMA = data.slice(0, period).reduce((sum, val) => sum + val, 0) / period;
  ema[period - 1] = firstSMA;

  // Расчёт последующих значений EMA
  for (let i = period; i < data.length; i++) {
    ema[i] = ((data[i] - ema[i - 1]) * multiplier) + ema[i - 1];
  }

  // Обрезаем undefined в начале и возвращаем результат
  return ema.slice(period - 1);
}

module.exports = { calculateEMA };